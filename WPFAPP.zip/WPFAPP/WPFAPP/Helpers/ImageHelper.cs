﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Media.Imaging;

namespace WPFAPP.Helpers
{
    public static class ImageHelper
    {
        private static readonly string ImagesFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images");

        static ImageHelper()
        {
            if (!Directory.Exists(ImagesFolder))
                Directory.CreateDirectory(ImagesFolder);
        }

        public static string SaveImage(string sourceImagePath, int productId, bool isNew = true)
        {
            if (string.IsNullOrEmpty(sourceImagePath) || !File.Exists(sourceImagePath))
                return null;

            string extension = Path.GetExtension(sourceImagePath);
            string fileName = $"product_{productId}{extension}";
            string targetPath = Path.Combine(ImagesFolder, fileName);

            if (!isNew && File.Exists(targetPath))
                File.Delete(targetPath);

            using (var srcImage = Image.FromFile(sourceImagePath))
            using (var bmp = new Bitmap(300, 200))
            using (var g = Graphics.FromImage(bmp))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.DrawImage(srcImage, 0, 0, 300, 200);
                bmp.Save(targetPath, GetImageFormat(extension));
            }
            return targetPath;
        }

        public static void DeleteImage(string fullPath)
        {
            if (!string.IsNullOrEmpty(fullPath) && File.Exists(fullPath))
                File.Delete(fullPath);
        }

        public static BitmapImage LoadImage(string fullPath)
        {
            if (string.IsNullOrEmpty(fullPath) || !File.Exists(fullPath))
                return null;

            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri(fullPath, UriKind.Absolute);
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.EndInit();
            bitmap.Freeze();
            return bitmap;
        }

        private static ImageFormat GetImageFormat(string extension)
        {
            switch (extension.ToLower())
            {
                case ".jpg":
                case ".jpeg":
                    return ImageFormat.Jpeg;
                case ".png":
                    return ImageFormat.Png;
                case ".bmp":
                    return ImageFormat.Bmp;
                default:
                    return ImageFormat.Jpeg;
            }
        }

        public static string GetPlaceholderPath()
        {
            string placeholder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "picture.png");
            if (File.Exists(placeholder))
                return placeholder;
            return null;
        }
    }
}