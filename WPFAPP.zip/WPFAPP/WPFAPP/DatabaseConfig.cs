﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFAPP
{
    public static class DatabaseConfig
    {
        public static string ConnectionString = @"Data Source=VASILEVGD\SQLEXPRESS;Initial Catalog=WPFAPP;Integrated Security=True;Encrypt=False";
    }
}