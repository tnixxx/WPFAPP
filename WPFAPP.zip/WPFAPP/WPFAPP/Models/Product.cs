﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFAPP.Models
{
    public class Product : ObservableObject
    {
        private int _productID;
        private string _productName;
        private int? _categoryID;
        private string _categoryName;
        private string _description;
        private int? _manufacturerID;
        private string _manufacturerName;
        private int? _supplierID;
        private string _supplierName;
        private decimal _price;
        private string _unit;
        private int _quantity;
        private int _discount;
        private string _imagePath;

        public int ProductID { get => _productID; set => SetProperty(ref _productID, value); }
        public string ProductName { get => _productName; set => SetProperty(ref _productName, value); }
        public int? CategoryID { get => _categoryID; set => SetProperty(ref _categoryID, value); }
        public string CategoryName { get => _categoryName; set => SetProperty(ref _categoryName, value); }
        public string Description { get => _description; set => SetProperty(ref _description, value); }
        public int? ManufacturerID { get => _manufacturerID; set => SetProperty(ref _manufacturerID, value); }
        public string ManufacturerName { get => _manufacturerName; set => SetProperty(ref _manufacturerName, value); }
        public int? SupplierID { get => _supplierID; set => SetProperty(ref _supplierID, value); }
        public string SupplierName { get => _supplierName; set => SetProperty(ref _supplierName, value); }
        public decimal Price { get => _price; set => SetProperty(ref _price, value); }
        public string Unit { get => _unit; set => SetProperty(ref _unit, value); }
        public int Quantity { get => _quantity; set => SetProperty(ref _quantity, value); }
        public int Discount { get => _discount; set => SetProperty(ref _discount, value); }
        public string ImagePath { get => _imagePath; set => SetProperty(ref _imagePath, value); }

        public decimal FinalPrice => Price * (1 - Discount / 100m);
        public string OldPriceString => Price.ToString("F2");
        public string FinalPriceString => FinalPrice.ToString("F2");

        // Для подсветки строки
        public bool IsOutOfStock => Quantity == 0;
        public bool IsHighDiscount => Discount > 15 && !IsOutOfStock;
    }
}