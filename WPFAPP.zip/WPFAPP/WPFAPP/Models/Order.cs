﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFAPP.Models
{
    public class Order : ObservableObject
    {
        private int _orderID;
        private int _productID;
        private string _productArticle; // Для отображения артикула (можно ProductID или отдельный артикул, но используем OrderID)
        private int _orderStatusID;
        private string _orderStatusName;
        private int _pickupPointID;
        private string _pickupPointAddress;
        private DateTime _orderDate;
        private DateTime? _deliveryDate; // дата выдачи

        public int OrderID { get => _orderID; set => SetProperty(ref _orderID, value); }
        public int ProductID { get => _productID; set => SetProperty(ref _productID, value); }

        // Для отображения в списке - обычно используют OrderID как артикул
        public string OrderArticle => $"Заказ №{OrderID}";

        public int OrderStatusID { get => _orderStatusID; set => SetProperty(ref _orderStatusID, value); }
        public string OrderStatusName { get => _orderStatusName; set => SetProperty(ref _orderStatusName, value); }

        public int PickupPointID { get => _pickupPointID; set => SetProperty(ref _pickupPointID, value); }
        public string PickupPointAddress { get => _pickupPointAddress; set => SetProperty(ref _pickupPointAddress, value); }

        public DateTime OrderDate { get => _orderDate; set => SetProperty(ref _orderDate, value); }
        public DateTime? DeliveryDate { get => _deliveryDate; set => SetProperty(ref _deliveryDate, value); }
    }
}