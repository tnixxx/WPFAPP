﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using WPFAPP.Models;

namespace WPFAPP.DAL
{
    public static class CategoryRepository
    {
        public static List<Category> GetAllCategories()
        {
            var list = new List<Category>();
            string query = "SELECT CategoryID, CategoryName FROM Categories ORDER BY CategoryName";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Category
                        {
                            CategoryID = reader.GetInt32(0),
                            CategoryName = reader.GetString(1)
                        });
                    }
                }
            }
            return list;
        }

        public static Category GetCategoryById(int id)
        {
            string query = "SELECT CategoryID, CategoryName FROM Categories WHERE CategoryID = @id";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Category
                        {
                            CategoryID = reader.GetInt32(0),
                            CategoryName = reader.GetString(1)
                        };
                    }
                }
            }
            return null;
        }
    }
}
