﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using WPFAPP.Models;

namespace WPFAPP.DAL
{
    public static class OrderStatusRepository
    {
        public static List<OrderStatus> GetAllOrderStatuses()
        {
            var list = new List<OrderStatus>();
            string query = "SELECT OrderStatusID, StatusName FROM OrderStatuses ORDER BY OrderStatusID";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new OrderStatus
                        {
                            OrderStatusID = reader.GetInt32(0),
                            StatusName = reader.GetString(1)
                        });
                    }
                }
            }
            return list;
        }

        public static OrderStatus GetOrderStatusById(int id)
        {
            string query = "SELECT OrderStatusID, StatusName FROM OrderStatuses WHERE OrderStatusID = @id";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new OrderStatus
                        {
                            OrderStatusID = reader.GetInt32(0),
                            StatusName = reader.GetString(1)
                        };
                    }
                }
            }
            return null;
        }
    }
}
