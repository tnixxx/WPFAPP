﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using WPFAPP.Models;

namespace WPFAPP.DAL
{
    public static class ProductRepository
    {
        public static List<Product> GetAllProducts()
        {
            var list = new List<Product>();
            string query = @"
                SELECT p.ProductID, p.ProductName, p.CategoryID, c.CategoryName,
                       p.Description, p.ManufacturerID, m.ManufacturerName,
                       p.SupplierID, s.SupplierName,
                       p.Price, p.Unit, p.Quantity, p.Discount, p.ImagePath
                FROM Products p
                LEFT JOIN Categories c ON p.CategoryID = c.CategoryID
                LEFT JOIN Manufacturers m ON p.ManufacturerID = m.ManufacturerID
                LEFT JOIN Suppliers s ON p.SupplierID = s.SupplierID";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var prod = new Product
                        {
                            ProductID = reader.GetInt32(0),
                            ProductName = reader.GetString(1),
                            CategoryID = reader.IsDBNull(2) ? null : (int?)reader.GetInt32(2),
                            CategoryName = reader.IsDBNull(3) ? null : reader.GetString(3),
                            Description = reader.IsDBNull(4) ? null : reader.GetString(4),
                            ManufacturerID = reader.IsDBNull(5) ? null : (int?)reader.GetInt32(5),
                            ManufacturerName = reader.IsDBNull(6) ? null : reader.GetString(6),
                            SupplierID = reader.IsDBNull(7) ? null : (int?)reader.GetInt32(7),
                            SupplierName = reader.IsDBNull(8) ? null : reader.GetString(8),
                            Price = reader.GetDecimal(9),
                            Unit = reader.GetString(10),
                            Quantity = reader.GetInt32(11),
                            Discount = reader.GetInt32(12),
                            ImagePath = reader.IsDBNull(13) ? null : reader.GetString(13)
                        };
                        list.Add(prod);
                    }
                }
            }
            return list;
        }

        public static void AddProduct(Product product)
        {
            string query = @"INSERT INTO Products (ProductName, CategoryID, Description, ManufacturerID, SupplierID, Price, Unit, Quantity, Discount, ImagePath)
                             VALUES (@name, @cat, @desc, @manuf, @supp, @price, @unit, @qty, @disc, @img);
                             SELECT SCOPE_IDENTITY();";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", product.ProductName);
                cmd.Parameters.AddWithValue("@cat", (object)product.CategoryID ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@desc", (object)product.Description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@manuf", (object)product.ManufacturerID ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@supp", (object)product.SupplierID ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@unit", product.Unit);
                cmd.Parameters.AddWithValue("@qty", product.Quantity);
                cmd.Parameters.AddWithValue("@disc", product.Discount);
                cmd.Parameters.AddWithValue("@img", (object)product.ImagePath ?? DBNull.Value);
                conn.Open();
                product.ProductID = Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public static void UpdateProduct(Product product)
        {
            string query = @"UPDATE Products SET ProductName=@name, CategoryID=@cat, Description=@desc,
                              ManufacturerID=@manuf, SupplierID=@supp, Price=@price, Unit=@unit,
                              Quantity=@qty, Discount=@disc, ImagePath=@img
                              WHERE ProductID=@id";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", product.ProductID);
                cmd.Parameters.AddWithValue("@name", product.ProductName);
                cmd.Parameters.AddWithValue("@cat", (object)product.CategoryID ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@desc", (object)product.Description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@manuf", (object)product.ManufacturerID ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@supp", (object)product.SupplierID ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@unit", product.Unit);
                cmd.Parameters.AddWithValue("@qty", product.Quantity);
                cmd.Parameters.AddWithValue("@disc", product.Discount);
                cmd.Parameters.AddWithValue("@img", (object)product.ImagePath ?? DBNull.Value);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static bool DeleteProduct(int productId)
        {
            // Проверка на наличие заказов
            string checkQuery = "SELECT COUNT(*) FROM Orders WHERE ProductID = @id";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var checkCmd = new SqlCommand(checkQuery, conn);
                checkCmd.Parameters.AddWithValue("@id", productId);
                conn.Open();
                int count = (int)checkCmd.ExecuteScalar();
                if (count > 0) return false; // Нельзя удалить
                string deleteQuery = "DELETE FROM Products WHERE ProductID = @id";
                var delCmd = new SqlCommand(deleteQuery, conn);
                delCmd.Parameters.AddWithValue("@id", productId);
                delCmd.ExecuteNonQuery();
                return true;
            }
        }

        public static List<Supplier> GetAllSuppliers()
        {
            var list = new List<Supplier>();
            string query = "SELECT SupplierID, SupplierName FROM Suppliers ORDER BY SupplierName";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                        list.Add(new Supplier { SupplierID = reader.GetInt32(0), SupplierName = reader.GetString(1) });
                }
            }
            return list;
        }

        // Аналогично для категорий, производителей...
    }
}