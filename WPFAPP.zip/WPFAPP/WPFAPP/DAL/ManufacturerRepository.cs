﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using WPFAPP.Models;

namespace WPFAPP.DAL
{
    public static class ManufacturerRepository
    {
        public static List<Manufacturer> GetAllManufacturers()
        {
            var list = new List<Manufacturer>();
            string query = "SELECT ManufacturerID, ManufacturerName FROM Manufacturers ORDER BY ManufacturerName";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Manufacturer
                        {
                            ManufacturerID = reader.GetInt32(0),
                            ManufacturerName = reader.GetString(1)
                        });
                    }
                }
            }
            return list;
        }

        public static Manufacturer GetManufacturerById(int id)
        {
            string query = "SELECT ManufacturerID, ManufacturerName FROM Manufacturers WHERE ManufacturerID = @id";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Manufacturer
                        {
                            ManufacturerID = reader.GetInt32(0),
                            ManufacturerName = reader.GetString(1)
                        };
                    }
                }
            }
            return null;
        }
    }
}