﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using WPFAPP.Models;

namespace WPFAPP.DAL
{
    public static class SupplierRepository
    {
        public static List<Supplier> GetAllSuppliers()
        {
            var list = new List<Supplier>();
            string query = "SELECT SupplierID, SupplierName FROM Suppliers ORDER BY SupplierName";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Supplier
                        {
                            SupplierID = reader.GetInt32(0),
                            SupplierName = reader.GetString(1)
                        });
                    }
                }
            }
            return list;
        }

        public static Supplier GetSupplierById(int id)
        {
            string query = "SELECT SupplierID, SupplierName FROM Suppliers WHERE SupplierID = @id";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Supplier
                        {
                            SupplierID = reader.GetInt32(0),
                            SupplierName = reader.GetString(1)
                        };
                    }
                }
            }
            return null;
        }
    }
}

