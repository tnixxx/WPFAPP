﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using WPFAPP.Models;

namespace WPFAPP.DAL
{
    public static class PickupPointRepository
    {
        public static List<PickupPoint> GetAllPickupPoints()
        {
            var list = new List<PickupPoint>();
            string query = "SELECT PickupPointID, Address FROM PickupPoints ORDER BY Address";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new PickupPoint
                        {
                            PickupPointID = reader.GetInt32(0),
                            Address = reader.GetString(1)
                        });
                    }
                }
            }
            return list;
        }

        public static PickupPoint GetPickupPointById(int id)
        {
            string query = "SELECT PickupPointID, Address FROM PickupPoints WHERE PickupPointID = @id";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new PickupPoint
                        {
                            PickupPointID = reader.GetInt32(0),
                            Address = reader.GetString(1)
                        };
                    }
                }
            }
            return null;
        }
    }
}