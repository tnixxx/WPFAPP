﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using WPFAPP.Models;

namespace WPFAPP.DAL
{
    public static class UserRepository
    {
        public static User GetUserByLoginPassword(string login, string password)
        {
            string query = "SELECT UserID, Login, Password, FullName, Role FROM Users WHERE Login = @login AND Password = @password";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@login", login);
                cmd.Parameters.AddWithValue("@password", password);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new User
                        {
                            UserID = reader.GetInt32(0),
                            Login = reader.GetString(1),
                            Password = reader.GetString(2),
                            FullName = reader.GetString(3),
                            Role = reader.GetString(4)
                        };
                    }
                }
            }
            return null;
        }
    }
}