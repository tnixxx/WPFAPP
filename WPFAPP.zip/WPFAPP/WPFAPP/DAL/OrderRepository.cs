﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using WPFAPP.Models;

namespace WPFAPP.DAL
{
    public static class OrderRepository
    {
        // Получить все заказы (с подгрузкой имени статуса и адреса пункта выдачи)
        public static List<Order> GetAllOrders()
        {
            var orders = new List<Order>();
            string query = @"
                SELECT o.OrderID, o.ProductID, o.OrderStatusID, os.StatusName,
                       o.PickupPointID, pp.Address, o.OrderDate, o.DeliveryDate
                FROM Orders o
                LEFT JOIN OrderStatuses os ON o.OrderStatusID = os.OrderStatusID
                LEFT JOIN PickupPoints pp ON o.PickupPointID = pp.PickupPointID
                ORDER BY o.OrderDate DESC";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var order = new Order
                        {
                            OrderID = reader.GetInt32(0),
                            ProductID = reader.GetInt32(1),
                            OrderStatusID = reader.GetInt32(2),
                            OrderStatusName = reader.IsDBNull(3) ? "" : reader.GetString(3),
                            PickupPointID = reader.GetInt32(4),
                            PickupPointAddress = reader.IsDBNull(5) ? "" : reader.GetString(5),
                            OrderDate = reader.GetDateTime(6),
                            DeliveryDate = reader.IsDBNull(7) ? (DateTime?)null : reader.GetDateTime(7)
                        };
                        orders.Add(order);
                    }
                }
            }
            return orders;
        }

        // Получить заказ по ID
        public static Order GetOrderById(int orderId)
        {
            string query = @"
                SELECT o.OrderID, o.ProductID, o.OrderStatusID, os.StatusName,
                       o.PickupPointID, pp.Address, o.OrderDate, o.DeliveryDate
                FROM Orders o
                LEFT JOIN OrderStatuses os ON o.OrderStatusID = os.OrderStatusID
                LEFT JOIN PickupPoints pp ON o.PickupPointID = pp.PickupPointID
                WHERE o.OrderID = @id";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", orderId);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Order
                        {
                            OrderID = reader.GetInt32(0),
                            ProductID = reader.GetInt32(1),
                            OrderStatusID = reader.GetInt32(2),
                            OrderStatusName = reader.IsDBNull(3) ? "" : reader.GetString(3),
                            PickupPointID = reader.GetInt32(4),
                            PickupPointAddress = reader.IsDBNull(5) ? "" : reader.GetString(5),
                            OrderDate = reader.GetDateTime(6),
                            DeliveryDate = reader.IsDBNull(7) ? (DateTime?)null : reader.GetDateTime(7)
                        };
                    }
                }
            }
            return null;
        }

        // Добавить заказ (дата заказа - текущая)
        public static void AddOrder(Order order)
        {
            string query = @"
                INSERT INTO Orders (ProductID, OrderStatusID, PickupPointID, OrderDate, DeliveryDate)
                VALUES (@productId, @statusId, @pickupPointId, GETDATE(), @deliveryDate);
                SELECT SCOPE_IDENTITY();";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@productId", order.ProductID);
                cmd.Parameters.AddWithValue("@statusId", order.OrderStatusID);
                cmd.Parameters.AddWithValue("@pickupPointId", order.PickupPointID);
                cmd.Parameters.AddWithValue("@deliveryDate", order.DeliveryDate.HasValue ? (object)order.DeliveryDate.Value : DBNull.Value);
                conn.Open();
                order.OrderID = Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        // Обновить заказ
        public static void UpdateOrder(Order order)
        {
            string query = @"
                UPDATE Orders 
                SET ProductID = @productId, 
                    OrderStatusID = @statusId, 
                    PickupPointID = @pickupPointId, 
                    DeliveryDate = @deliveryDate
                WHERE OrderID = @orderId";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@orderId", order.OrderID);
                cmd.Parameters.AddWithValue("@productId", order.ProductID);
                cmd.Parameters.AddWithValue("@statusId", order.OrderStatusID);
                cmd.Parameters.AddWithValue("@pickupPointId", order.PickupPointID);
                cmd.Parameters.AddWithValue("@deliveryDate", order.DeliveryDate.HasValue ? (object)order.DeliveryDate.Value : DBNull.Value);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // Удалить заказ (без дополнительных проверок, т.к. заказы не связаны с другими сущностями кроме товара, но товар удалять нельзя при наличии заказов)
        public static bool DeleteOrder(int orderId)
        {
            string query = "DELETE FROM Orders WHERE OrderID = @id";
            using (var conn = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", orderId);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows > 0;
            }
        }
    }
}