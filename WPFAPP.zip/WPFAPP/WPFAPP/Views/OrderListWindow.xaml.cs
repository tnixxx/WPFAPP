﻿using System.Collections.Generic;
using System.Windows;
using WPFAPP.DAL;
using WPFAPP.Models;
using WPFAPP.Views;

namespace WPFAPP
{
    public partial class OrderListWindow : Window
    {
        private List<Order> _orders;

        public OrderListWindow()
        {
            InitializeComponent();
            DataContext = this;
            LoadOrders();
        }

        public string CurrentUserFullName => App.CurrentUser.FullName;
        public Visibility AddButtonVisibility => (App.CurrentUser.Role == "Администратор") ? Visibility.Visible : Visibility.Collapsed;
        public List<Order> Orders { get; private set; }

        private void LoadOrders()
        {
            _orders = OrderRepository.GetAllOrders();
            Orders = _orders;
            ordersItemsControl.ItemsSource = Orders;
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            var editWin = new OrderEditWindow();
            if (editWin.ShowDialog() == true)
                LoadOrders();
        }

        private void EditOrder_Click(object sender, RoutedEventArgs e)
        {
            var order = (sender as FrameworkElement)?.Tag as Order;
            if (order != null)
            {
                var editWin = new OrderEditWindow(order);
                if (editWin.ShowDialog() == true)
                    LoadOrders();
            }
        }

        private void DeleteOrder_Click(object sender, RoutedEventArgs e)
        {
            var order = (sender as FrameworkElement)?.Tag as Order;
            if (order != null)
            {
                if (MessageBox.Show($"Удалить заказ №{order.OrderID}?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    OrderRepository.DeleteOrder(order.OrderID);
                    LoadOrders();
                }
            }
        }

        private void BackToProducts_Click(object sender, RoutedEventArgs e)
        {
            var productWin = new ProductListWindow();
            productWin.Show();
            this.Close();
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            var loginWin = new LoginWindow();
            loginWin.Show();
            this.Close();
        }
    }
}