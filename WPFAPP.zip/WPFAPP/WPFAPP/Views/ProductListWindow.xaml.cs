﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using WPFAPP.DAL;
using WPFAPP.Helpers;
using WPFAPP.Models;

namespace WPFAPP.Views
{
    public partial class ProductListWindow : Window
    {
        private List<Product> _allProducts;
        private ICollectionView _productsView;
        private string _currentSearchText = "";
        private int? _currentSupplierFilter = null;
        private string _currentSortDirection = null;

        public ProductListWindow()
        {
            InitializeComponent();
            DataContext = this;
            LoadProducts();
            SetupFiltersAndButtons();
        }

        public string CurrentUserFullName => App.CurrentUser?.FullName ?? "Гость";
        public Visibility FilterPanelVisibility => (App.CurrentUser.Role == "Менеджер" || App.CurrentUser.Role == "Администратор") ? Visibility.Visible : Visibility.Collapsed;
        public Visibility AddButtonVisibility => (App.CurrentUser.Role == "Администратор") ? Visibility.Visible : Visibility.Collapsed;
        public Visibility OrdersButtonVisibility => (App.CurrentUser.Role == "Менеджер" || App.CurrentUser.Role == "Администратор") ? Visibility.Visible : Visibility.Collapsed;
        public ICollectionView ProductsView => _productsView;

        private void LoadProducts()
        {
            _allProducts = ProductRepository.GetAllProducts();
            _productsView = CollectionViewSource.GetDefaultView(_allProducts);
            ApplyFilterAndSort();
            productsItemsControl.ItemsSource = _productsView;
        }

        private void SetupFiltersAndButtons()
        {
            if (App.CurrentUser.Role == "Менеджер" || App.CurrentUser.Role == "Администратор")
            {
                var suppliers = ProductRepository.GetAllSuppliers();
                suppliers.Insert(0, new Supplier { SupplierID = 0, SupplierName = "Все поставщики" });
                supplierFilterCombo.ItemsSource = suppliers;
                supplierFilterCombo.DisplayMemberPath = "SupplierName";
                supplierFilterCombo.SelectedValuePath = "SupplierID";
                supplierFilterCombo.SelectedIndex = 0;
            }
        }

        private void ApplyFilterAndSort()
        {
            if (_productsView != null)
            {
                _productsView.Filter = FilterPredicate;
                ApplySort();
            }
        }

        private bool FilterPredicate(object item)
        {
            var product = item as Product;
            if (product == null) return false;

            if (!string.IsNullOrEmpty(_currentSearchText))
            {
                string search = _currentSearchText.ToLower();
                if (!(product.ProductName?.ToLower().Contains(search) == true ||
                      product.Description?.ToLower().Contains(search) == true ||
                      product.CategoryName?.ToLower().Contains(search) == true ||
                      product.ManufacturerName?.ToLower().Contains(search) == true ||
                      product.SupplierName?.ToLower().Contains(search) == true))
                    return false;
            }

            if (_currentSupplierFilter.HasValue && _currentSupplierFilter.Value > 0)
            {
                if (product.SupplierID != _currentSupplierFilter.Value)
                    return false;
            }
            return true;
        }

        private void ApplySort()
        {
            _productsView.SortDescriptions.Clear();
            if (_currentSortDirection == "asc")
            {
                _productsView.SortDescriptions.Add(new SortDescription("Quantity", ListSortDirection.Ascending));
            }
            else if (_currentSortDirection == "desc")
            {
                _productsView.SortDescriptions.Add(new SortDescription("Quantity", ListSortDirection.Descending));
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            _currentSearchText = searchBox.Text;
            _productsView?.Refresh();
        }

        private void SupplierFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (supplierFilterCombo.SelectedItem is Supplier supplier)
            {
                _currentSupplierFilter = supplier.SupplierID == 0 ? (int?)null : supplier.SupplierID;
                _productsView?.Refresh();
            }
        }

        private void SortByQuantityAsc_Click(object sender, RoutedEventArgs e)
        {
            _currentSortDirection = "asc";
            ApplySort();
        }

        private void SortByQuantityDesc_Click(object sender, RoutedEventArgs e)
        {
            _currentSortDirection = "desc";
            ApplySort();
        }

        private void Orders_Click(object sender, RoutedEventArgs e)
        {
            var ordersWindow = new OrderListWindow();
            ordersWindow.Show();
            Close();
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            var editWin = new ProductEditWindow();
            if (editWin.ShowDialog() == true)
                LoadProducts();
        }

        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            var product = (sender as FrameworkElement)?.Tag as Product;
            if (product != null)
            {
                var editWin = new ProductEditWindow(product);
                if (editWin.ShowDialog() == true)
                    LoadProducts();
            }
        }

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            var product = (sender as FrameworkElement)?.Tag as Product;
            if (product != null)
            {
                if (MessageBox.Show($"Удалить товар \"{product.ProductName}\"?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    bool success = ProductRepository.DeleteProduct(product.ProductID);
                    if (success)
                    {
                        if (!string.IsNullOrEmpty(product.ImagePath) && File.Exists(product.ImagePath))
                            ImageHelper.DeleteImage(product.ImagePath);
                        LoadProducts();
                        MessageBox.Show("Товар удалён", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("Нельзя удалить товар, который присутствует в заказах", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            var loginWin = new LoginWindow();
            loginWin.Show();
            Close();
        }
    }
}