﻿using System.Windows;
using WPFAPP.DAL;
using WPFAPP.Models;

namespace WPFAPP.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Password;
            var user = UserRepository.GetUserByLoginPassword(login, password);
            if (user != null)
            {
                App.CurrentUser = user;
                OpenProductListWindow();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnGuest_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentUser = new User { Role = "guest", FullName = "Гость" };
            OpenProductListWindow();
        }

        private void OpenProductListWindow()
        {
            var productList = new ProductListWindow();
            productList.Show();
            this.Close();
        }
    }
}