﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using WPFAPP.DAL;
using WPFAPP.Models;

namespace WPFAPP
{
    public partial class OrderEditWindow : Window, INotifyPropertyChanged
    {
        private Order _order;
        private bool _isEdit;

        public Order Order { get => _order; set { _order = value; OnPropertyChanged(nameof(Order)); } }
        public bool IsEdit { get => _isEdit; set { _isEdit = value; OnPropertyChanged(nameof(IsEdit)); OnPropertyChanged(nameof(Title)); } }
        public new string Title => IsEdit ? "Редактирование заказа" : "Добавление заказа";

        public List<ProductForOrder> Products { get; set; }
        public List<OrderStatus> OrderStatuses { get; set; }
        public List<PickupPoint> PickupPoints { get; set; }

        public OrderEditWindow(Order order = null)
        {
            InitializeComponent();
            DataContext = this;
            LoadLists();

            if (order != null)
            {
                Order = new Order
                {
                    OrderID = order.OrderID,
                    ProductID = order.ProductID,
                    OrderStatusID = order.OrderStatusID,
                    PickupPointID = order.PickupPointID,
                    OrderDate = order.OrderDate,
                    DeliveryDate = order.DeliveryDate
                };
                IsEdit = true;
            }
            else
            {
                Order = new Order { OrderDate = DateTime.Now, DeliveryDate = null };
                IsEdit = false;
            }
        }

        private void LoadLists()
        {
            // Получаем товары для выбора
            var allProducts = ProductRepository.GetAllProducts();
            Products = allProducts.Select(p => new ProductForOrder { ProductID = p.ProductID, DisplayName = $"Арт.{p.ProductID} - {p.ProductName}" }).ToList();
            OnPropertyChanged(nameof(Products));

            OrderStatuses = OrderStatusRepository.GetAllOrderStatuses();
            PickupPoints = PickupPointRepository.GetAllPickupPoints();
            OnPropertyChanged(nameof(OrderStatuses));
            OnPropertyChanged(nameof(PickupPoints));
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            // Валидация
            if (Order.ProductID == 0)
            {
                MessageBox.Show("Выберите товар", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (Order.OrderStatusID == 0)
            {
                MessageBox.Show("Выберите статус", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (Order.PickupPointID == 0)
            {
                MessageBox.Show("Выберите пункт выдачи", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (Order.DeliveryDate.HasValue && Order.DeliveryDate.Value < Order.OrderDate)
            {
                MessageBox.Show("Дата выдачи не может быть раньше даты заказа", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                if (IsEdit)
                    OrderRepository.UpdateOrder(Order);
                else
                    OrderRepository.AddOrder(Order);

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    // Вспомогательный класс для ComboBox
    public class ProductForOrder
    {
        public int ProductID { get; set; }
        public string DisplayName { get; set; }
    }
}