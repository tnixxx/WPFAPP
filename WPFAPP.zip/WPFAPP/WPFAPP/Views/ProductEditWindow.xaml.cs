﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using WPFAPP.DAL;
using WPFAPP.Models;
using WPFAPP.Helpers;
using System.Windows.Media.Imaging;

namespace WPFAPP.Views   // ← пространство имён исправлено
{
    public partial class ProductEditWindow : Window, INotifyPropertyChanged
    {
        private Product _product;
        private bool _isEdit;
        private string _oldImagePath;
        private string _selectedImagePath;

        public Product Product { get => _product; set { _product = value; OnPropertyChanged(nameof(Product)); } }
        public bool IsEdit { get => _isEdit; set { _isEdit = value; OnPropertyChanged(nameof(IsEdit)); OnPropertyChanged(nameof(Title)); } }
        public new string Title => IsEdit ? "Редактирование товара" : "Добавление товара";  // ← new

        public List<Category> Categories { get; set; }
        public List<Manufacturer> Manufacturers { get; set; }
        public List<Supplier> Suppliers { get; set; }

        public ProductEditWindow(Product product = null)
        {
            InitializeComponent();
            DataContext = this;
            LoadLists();

            if (product != null)
            {
                Product = new Product
                {
                    ProductID = product.ProductID,
                    ProductName = product.ProductName,
                    CategoryID = product.CategoryID,
                    Description = product.Description,
                    ManufacturerID = product.ManufacturerID,
                    SupplierID = product.SupplierID,
                    Price = product.Price,
                    Unit = product.Unit,
                    Quantity = product.Quantity,
                    Discount = product.Discount,
                    ImagePath = product.ImagePath
                };
                _oldImagePath = product.ImagePath;
                IsEdit = true;
                if (!string.IsNullOrEmpty(Product.ImagePath) && File.Exists(Product.ImagePath))
                    productImage.Source = ImageHelper.LoadImage(Product.ImagePath);  // ← previewImage → productImage
            }
            else
            {
                Product = new Product { Quantity = 0, Discount = 0, Price = 0 };
                IsEdit = false;
            }
        }

        private void LoadLists()
        {
            Categories = CategoryRepository.GetAllCategories();
            Manufacturers = ManufacturerRepository.GetAllManufacturers();
            Suppliers = SupplierRepository.GetAllSuppliers();
            OnPropertyChanged(nameof(Categories));
            OnPropertyChanged(nameof(Manufacturers));
            OnPropertyChanged(nameof(Suppliers));
        }

        private void SelectImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog();
            dialog.Filter = "Image files (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp";
            if (dialog.ShowDialog() == true)
            {
                _selectedImagePath = dialog.FileName;
                productImage.Source = new BitmapImage(new Uri(_selectedImagePath));  // ← previewImage → productImage
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Product.ProductName))
            {
                MessageBox.Show("Введите наименование товара", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (Product.Price <= 0)
            {
                MessageBox.Show("Цена должна быть положительным числом", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (Product.Quantity < 0)
            {
                MessageBox.Show("Количество не может быть отрицательным", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (Product.Discount < 0 || Product.Discount > 100)
            {
                MessageBox.Show("Скидка должна быть от 0 до 100", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!string.IsNullOrEmpty(_selectedImagePath))
            {
                string newImagePath = ImageHelper.SaveImage(_selectedImagePath, Product.ProductID, !IsEdit);
                if (!string.IsNullOrEmpty(newImagePath))
                {
                    if (IsEdit && !string.IsNullOrEmpty(_oldImagePath) && _oldImagePath != newImagePath)
                        ImageHelper.DeleteImage(_oldImagePath);
                    Product.ImagePath = newImagePath;
                }
            }
            else if (IsEdit && string.IsNullOrEmpty(_selectedImagePath) && !string.IsNullOrEmpty(_oldImagePath))
            {
                Product.ImagePath = _oldImagePath;
            }

            try
            {
                if (IsEdit)
                    ProductRepository.UpdateProduct(Product);
                else
                    ProductRepository.AddProduct(Product);

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}