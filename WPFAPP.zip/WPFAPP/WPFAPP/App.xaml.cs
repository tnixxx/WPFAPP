﻿using System.Configuration;
using System.Data;
using System.Windows;
using WPFAPP.Models;

namespace WPFAPP
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static User CurrentUser { get; set; }
    }

}
