﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace WPFAPP.Converters
{
    public class DateToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // Если значение не null (т.е. дата задана) – Visible, иначе Collapsed
            return value != null ? Visibility.Visible : Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}